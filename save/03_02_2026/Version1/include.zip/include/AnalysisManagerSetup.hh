#ifndef ANALYSIS_MANAGER_SETUP_HH
#define ANALYSIS_MANAGER_SETUP_HH

// Initialisation de l'analyse avec G4AnalysisManager
void SetupAnalysis();

// Finalisation de l'analyse
// Enregistre les données et ferme le fichier
void FinalizeAnalysis();

// Exposer l'ID du ntuple "plane_passages" créé dans SetupAnalysis
// Retourne -1 si non configuré.
int GetPlanePassageNtupleId();

// Exposer l'ID du ntuple "ScorePlane2_passages" créé dans SetupAnalysis
// Retourne -1 si non configuré.
int GetScorePlane2NtupleId();

// Exposer l'ID du ntuple "ScorePlane3_passages" créé dans SetupAnalysis
// Retourne -1 si non configuré.
int GetScorePlane3NtupleId();

// Exposer l'ID du ntuple "ScorePlane4_passages" créé dans SetupAnalysis
// Retourne -1 si non configuré.
int GetScorePlane4NtupleId();

// Exposer l'ID du ntuple "ScorePlane5_passages" créé dans SetupAnalysis
// Retourne -1 si non configuré.
int GetScorePlane5NtupleId();

// GetScorePlane6NtupleId() supprimé

#endif
